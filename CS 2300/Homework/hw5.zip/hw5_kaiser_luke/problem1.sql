-- Part A
SELECT
    E.fname,
    E.lname
FROM
    employee AS E
JOIN
    works_on AS W ON E.ssn = W.essn
JOIN
    project AS P ON W.pno = P.pnumber
WHERE
    E.dno = 5
    AND P.pname = 'ProductX'
    AND W.hours > 10;

-- Part B
SELECT
    E.fname,
    E.lname
FROM
    employee AS E
JOIN
    dependent AS D ON E.ssn = D.essn
WHERE
    E.fname = D.dependent_name;

-- Part C
SELECT
    E.fname,
    E.lname
FROM
    employee AS E
WHERE
    E.super_ssn = (
        SELECT
            ssn
        FROM
            employee
        WHERE
            fname = 'Franklin'
            AND lname = 'Wong'
    );

-- Part D
SELECT
    P.pname,
    SUM(W.hours) AS total_hours_per_week
FROM
    project AS P
JOIN
    works_on AS W ON P.pnumber = W.pno
GROUP BY
    P.pname;

-- Part E
SELECT
    E.fname,
    E.lname
FROM
    employee AS E
JOIN
    works_on AS W ON E.ssn = W.essn
GROUP BY
    E.ssn, E.fname, E.lname
HAVING
    COUNT(W.pno) = (SELECT COUNT(*) FROM project);

-- Part F
SELECT
    fname,
    lname
FROM
    employee
WHERE
    ssn NOT IN (SELECT essn FROM works_on);

-- Part G
SELECT
    D.dname,
    AVG(E.salary) AS average_salary
FROM
    department AS D
JOIN
    employee AS E ON D.dnumber = E.dno
GROUP BY
    D.dname;

-- Part H
SELECT
    AVG(salary) AS average_female_salary
FROM
    employee
WHERE
    sex = 'F';

-- Part I
SELECT
    D.dname,
    D.mgr_ssn,
    QE.fname,
    QE.lname,
    QE.ssn,
    QE.total_hours
FROM
    department AS D
LEFT JOIN
    (
        SELECT
            E.ssn,
            E.fname,
            E.lname,
            E.dno,
            SUM(W.hours) AS total_hours
        FROM
            employee AS E
        JOIN
            works_on AS W ON E.ssn = W.essn
        GROUP BY
            E.ssn, E.fname, E.lname, E.dno
        HAVING
            SUM(W.hours) > 100
    ) AS QE ON D.dnumber = QE.dno
ORDER BY
    D.dname;
