-- Artist Table
DROP TABLE IF EXISTS Artist;
CREATE TABLE Artist (
    aid INT PRIMARY KEY,
    aname VARCHAR(80) NOT NULL
);

-- Label Table
DROP TABLE IF EXISTS Label;
CREATE TABLE Label (
    lid INT PRIMARY KEY,
    lname VARCHAR(80) NOT NULL,
    labbr VARCHAR(5)
);

-- Release Table
DROP TABLE IF EXISTS Release;
CREATE TABLE Release (
    rid INT PRIMARY KEY,
    rtitle VARCHAR(80) NOT NULL,
    year INT CHECK (year >= 1900),
    aid INT NOT NULL,
    FOREIGN KEY (aid) REFERENCES Artist(aid) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Song Table
DROP TABLE IF EXISTS Song;
CREATE TABLE Song (
    sid INT PRIMARY KEY,
    stitle VARCHAR(80) NOT NULL,
    duration INT NOT NULL CHECK (duration > 0),
    remixof INT,
    artist INT NOT NULL,
    FOREIGN KEY (artist) REFERENCES Artist(aid) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (remixof) REFERENCES Song(sid) ON DELETE SET NULL ON UPDATE CASCADE
);

-- Rerelease Table
DROP TABLE IF EXISTS Rerelease;
CREATE TABLE Rerelease (
    catno VARCHAR(80),
    rid INT,
    upc VARCHAR(12),
    label INT NOT NULL,
    year INT CHECK (year >= 1900),
    medium VARCHAR(20) CHECK (medium IN ('CD', 'Web', 'LP', '45', 'Tape')),
    PRIMARY KEY (catno, rid),
    FOREIGN KEY (rid) REFERENCES Release(rid) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (label) REFERENCES Label(lid) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- AlbumTrack Table
DROP TABLE IF EXISTS AlbumTrack;
CREATE TABLE AlbumTrack (
    rid INT,
    catno VARCHAR(80),
    sid INT,
    trackno INT NOT NULL,
    PRIMARY KEY (rid, catno, sid),
    FOREIGN KEY (rid, catno) REFERENCES Rerelease(rid, catno) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (sid) REFERENCES Song(sid) ON DELETE CASCADE ON UPDATE CASCADE
);


-- Insert into parent tables
INSERT INTO Artist (aid, aname) VALUES
(1, 'deadmau5');

INSERT INTO Label (lid, lname, labbr) VALUES
(1, 'Ultra Records', 'UL'),
(2, 'mau5trap', 'MAU');

-- Insert into tables that depend on Artist and Label
INSERT INTO Release (rid, rtitle, year, aid) VALUES
(1, 'Random Album Title.', 2008, 1);

INSERT INTO Song (sid, stitle, duration, remixof, artist) VALUES
(1, 'Brazil (2nd Edit)', 323, NULL, 1),
(2, 'I Remember', 548, NULL, 1),
(4, 'Faxing Berlin', 150, NULL, 1),
(3, 'Faxing Berlin (Piano Acoustica Version)', 105, 4, 1);

-- Insert into Rerelease, which depends on Release and Label
INSERT INTO Rerelease (catno, rid, upc, label, year, medium) VALUES
('UL 1868-2', 1, '617465186820', 1, 2008, 'CD'),
('MAU5RAT', 1, NULL, 2, 2016, 'Web');

-- Insert into the linking table AlbumTrack
INSERT INTO AlbumTrack (rid, catno, sid, trackno) VALUES
(1, 'UL 1868-2', 1, 5),
(1, 'UL 1868-2', 2, 7),
(1, 'UL 1868-2', 3, 8),
(1, 'UL 1868-2', 4, 9),
(1, 'MAU5RAT', 1, 5),
(1, 'MAU5RAT', 2, 7),
(1, 'MAU5RAT', 3, 8),
(1, 'MAU5RAT', 4, 9);

SELECT * FROM Artist;
SELECT * FROM Label;
SELECT * FROM Release;
SELECT * FROM Song;
SELECT * FROM Rerelease;
SELECT * FROM AlbumTrack;

-- Find song titles from songs on rereleases after 2008 on Ultra Records
SELECT
    S.stitle
FROM
    Song AS S
JOIN
    AlbumTrack AS AT ON S.sid = AT.sid
JOIN
    Rerelease AS RR ON AT.rid = RR.rid AND AT.catno = RR.catno
JOIN
    Label AS L ON RR.label = L.lid
WHERE
    L.lname = 'Ultra Records' AND RR.year > 2008;


-- For each rerelease, list release title, rerelease year, and number of songs.
SELECT
    R.rtitle,
    RR.year,
    COUNT(AT.sid) AS album_track_count
FROM
    Release AS R
JOIN
    Rerelease AS RR ON R.rid = RR.rid
JOIN
    AlbumTrack AS AT ON RR.rid = AT.rid AND RR.catno = AT.catno
GROUP BY
    R.rtitle,
    RR.year
ORDER BY
    RR.year DESC;


-- Compute the runtime of each rerelease.
SELECT
    R.rtitle,
    RR.catno,
    SUM(S.duration) AS total_duration
FROM
    Release AS R
JOIN
    Rerelease AS RR ON R.rid = RR.rid
JOIN
    AlbumTrack AS AT ON RR.rid = AT.rid AND RR.catno = AT.catno
JOIN
    Song AS S ON AT.sid = S.sid
GROUP BY
    R.rtitle,
    RR.catno;

-- For each remixed song, display its details and the original's details.
SELECT
    Remix.stitle AS remix,
    Remix.duration,
    RemixArtist.aname AS remixing_artist,
    Original.stitle AS original,
    OriginalArtist.aname AS original_artist
FROM
    Song AS Remix
JOIN
    Song AS Original ON Remix.remixof = Original.sid
JOIN
    Artist AS RemixArtist ON Remix.artist = RemixArtist.aid
JOIN
    Artist AS OriginalArtist ON Original.artist = OriginalArtist.aid
WHERE
    Remix.remixof IS NOT NULL;

-- DROP TABLES
DROP TABLE AlbumTrack;
DROP TABLE Rerelease;
DROP TABLE Song;
DROP TABLE Release;
DROP TABLE Label;
DROP TABLE Artist;