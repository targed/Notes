import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
import student_hw2 as hw 


###################### Part 1 ################################################

def generate_separable_dataset(n_samples=50, seed=42):
    """
    Generates a linearly separable 2D dataset with 50 points.
    25 points for class +1, 25 points for class -1.
    """
    np.random.seed(seed)
    
    # class +1 centered at (2, 2)
    # class -1 centered at (-2, -2)
    mean_pos = [2, 2]
    mean_neg = [-2, -2]
    std_dev = 0.8 
    
    n_per_class = n_samples // 2

    # generate samples
    X_pos = np.random.randn(n_per_class, 2) * std_dev + mean_pos
    y_pos = np.ones(n_per_class)
    X_neg = np.random.randn(n_per_class, 2) * std_dev + mean_neg
    y_neg = -1 * np.ones(n_per_class)

    # combine stuff
    X = np.vstack([X_pos, X_neg])
    y = np.hstack([y_pos, y_neg])

    return X, y

# generate the data
X, y = generate_separable_dataset()

# plot to confirm linear separability
plt.figure(figsize=(8, 6))
plt.scatter(X[y==1][:, 0], X[y==1][:, 1], c='blue', label='Class +1', edgecolors='k')
plt.scatter(X[y==-1][:, 0], X[y==-1][:, 1], c='green', label='Class -1', edgecolors='k')
plt.title("Part 1: Linearly Separable Dataset")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.show()

# If running this independently, uncomment the line below to regenerate the dataset
# X, y = generate_separable_dataset() 

###################### Part 2 ################################################


plt.figure(figsize=(8, 6))

# plot the points
# class +1 -> Blue
# class -1 -> Green
plt.scatter(X[y==1][:, 0], X[y==1][:, 1], c='blue', label='Class +1', edgecolors='k', zorder=10)
plt.scatter(X[y==-1][:, 0], X[y==-1][:, 1], c='green', label='Class -1', edgecolors='k', zorder=10)

# x-axis range for plotting line
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
x_values = np.linspace(x_min, x_max, 100)

#  10 Experiments
np.random.seed(100)
for i in range(10):
    # random init
    w_init = np.random.uniform(-1, 1, size=2) 
    b_init = np.random.uniform(-1, 1)
    
    # train perceptron
    w_p, b_p = hw.perceptron_gradient_descent(X, y, w_init, b_init, lr=0.1, max_iter=2000)
    
    # calculate Line
    if abs(w_p[1]) > 1e-5:
        slope_p = -w_p[0] / w_p[1]
        intercept_p = -b_p / w_p[1]
        y_p = slope_p * x_values + intercept_p
        
        # plot lines
        label = "Perceptron (10 runs)" if i == 0 else ""
        plt.plot(x_values, y_p, color='black', alpha=0.3, linewidth=1, label=label)
        
# Train Linear SVM
# C=1000 simulates a Hard Margin SVM
clf = SVC(kernel='linear', C=1000)
clf.fit(X, y)

# Extract Weights and Bias
w_svm = clf.coef_[0]
b_svm = clf.intercept_[0]

# calculate and plot line
slope_svm = -w_svm[0] / w_svm[1]
intercept_svm = -b_svm / w_svm[1]
y_svm = slope_svm * x_values + intercept_svm
plt.plot(x_values, y_svm, color='red', linewidth=3, label='SVM Boundary')

# plot stuff
plt.title("Part 3: Perceptron (Unstable) vs SVM (Stable)")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.ylim(X[:, 1].min() - 2, X[:, 1].max() + 2)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()


###################### Part 5 ################################################

# create a copy of y to avoid messing up previous parts
y_noisy = y.copy()

# indices for each class
idx_pos = np.where(y == 1)[0]
idx_neg = np.where(y == -1)[0]

# Randomly select 5 indices from each class to flip
np.random.seed(42)
flip_pos = np.random.choice(idx_pos, 5, replace=False)
flip_neg = np.random.choice(idx_neg, 5, replace=False)

# flip labels
y_noisy[flip_pos] = -1
y_noisy[flip_neg] = 1

print(f"Flipped {len(flip_pos)} positive labels and {len(flip_neg)} negative labels.")

###################### Part 6 ################################################

C_values = [0.01, 0.1, 1, 10, 100]

# x-axis range for drawing lines
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
x_values = np.linspace(x_min, x_max, 100)

for C_val in C_values:
    # train SVM with specific C
    clf = SVC(kernel='linear', C=C_val)
    clf.fit(X, y_noisy) # Note: Training on X and y_noisy
    
    # extract weights and bias
    w = clf.coef_[0]
    b = clf.intercept_[0]
    
    plt.figure(figsize=(8, 6))
    
    # plot Noisy Data
    # Plot Class +1 (Blue)
    # Plot Class -1 (Green)
    plt.scatter(X[y_noisy==1][:, 0], X[y_noisy==1][:, 1], c='blue', label='Class +1', edgecolors='k')
    plt.scatter(X[y_noisy==-1][:, 0], X[y_noisy==-1][:, 1], c='green', label='Class -1', edgecolors='k')
    
    # plot Decision Boundary
    if abs(w[1]) > 1e-5:
        slope = -w[0] / w[1]
        intercept = -b / w[1]
        y_line = slope * x_values + intercept
        
        plt.plot(x_values, y_line, color='red', linewidth=3, label=f'SVM (C={C_val})')
    
    plt.title(f"Part 6: Soft Margin SVM with C={C_val}")
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.ylim(X[:, 1].min() - 2, X[:, 1].max() + 2)
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.6)
    
    # highlight flipped points (optional, I thought it looks nice)
    plt.scatter(X[flip_pos][:, 0], X[flip_pos][:, 1], facecolors='none', edgecolors='red', s=150, linewidth=2, label='Flipped (Orig +1)')
    plt.scatter(X[flip_neg][:, 0], X[flip_neg][:, 1], facecolors='none', edgecolors='orange', s=150, linewidth=2, label='Flipped (Orig -1)')
    
    plt.show()