import math
import numpy as np
import matplotlib.pyplot as plt
import random
from collections import Counter, defaultdict
# Do not import any other libraries. You can use built-in functions and the above imports only.


###################### Task-1 ################################################

def entropy(labels):
    """
    Compute entropy of a list of class labels.
    """
    total_count = len(labels)
    if total_count == 0:
        return 0.0
    
    # Count frequency of each class label
    label_counts = Counter(labels)
    
    ent = 0.0
    for count in label_counts.values():
        p = count / total_count
        # sum(p * log2(p))
        if p > 0:
            ent -= p * math.log2(p)
    
    return ent


def information_gain(dataset):
    """
    Input:
        dataset: list of lists
                 last column is label
    Output:
        list of information gain for each feature
    """
    ig_list = []
    
    if not dataset:
        return []

    # get total number of rows and features which are cols 0 to N-2 
    num_rows = len(dataset)
    num_features = len(dataset[0]) - 1
    
    # calculate Parent Entropy and extract all labels
    all_labels = [row[-1] for row in dataset]
    parent_entropy = entropy(all_labels)
    
    #  Calculate IG for each feature
    for feature_index in range(num_features):
        # split the dataset
        # map feature_value -> list of class labels for rows with that value
        feature_value_to_labels = defaultdict(list)
        
        for row in dataset:
            feature_val = row[feature_index]
            label = row[-1]
            feature_value_to_labels[feature_val].append(label)
        
        # calculate weighted average entropy of children
        weighted_child_entropy = 0.0
        
        for val, subset_labels in feature_value_to_labels.items():
            subset_size = len(subset_labels)
            probability = subset_size / num_rows
            child_ent = entropy(subset_labels)
            
            weighted_child_entropy += probability * child_ent
            
        ig = parent_entropy - weighted_child_entropy
        ig_list.append(ig)

    return ig_list



###################### Task-2 ################################################
def perceptron_gradient_descent(X, y, w_init, b_init, lr=1.0, max_iter=100):
    """
    Parameters:
        X : list of feature vectors
        y : list of labels (-1 or +1)
        w_init : initial weight vector
        b_init : initial bias
        lr : learning rate
        max_iter : maximum iterations
        
    Returns:
        w, b
    """
    # convert to numpy arrays
    X_mat = np.array(X)
    y_vec = np.array(y)
    w = np.array(w_init, dtype=float)
    b = float(b_init)
    
    n_samples = X_mat.shape[0]

    for _ in range(max_iter):
        misclassified_indices = []
        
        # identify all misclassified samples if y * (w.x + b) <= 0
        for i in range(n_samples):
            prediction_score = np.dot(w, X_mat[i]) + b
            if y_vec[i] * prediction_score <= 0:
                misclassified_indices.append(i)
        
        # If no samples are misclassified, the data is linearly separated
        if not misclassified_indices:
            break
            
        # Choose the sample with the largest data ID (index)
        target_idx = max(misclassified_indices)
        
        # perform an update
        w = w + lr * y_vec[target_idx] * X_mat[target_idx]
        b = b + lr * y_vec[target_idx]
        
    
    return w, b