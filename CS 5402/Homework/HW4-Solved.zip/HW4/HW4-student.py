import numpy as np
# not allowed to import any other libraries.

class CustomConv2D:
    def __init__(self, kernel):
        """
        kernel: 2D numpy array (kH x kW)
        """
        self.kernel = kernel
        self.kH, self.kW = kernel.shape

    
    def forward(self, input):
        """
        input: 2D numpy array (H x W)

        Returns:
            output: 2D numpy array
        """
        H, W = input.shape
        
        # calculate the maximum valid starting indices
        max_i = H - self.kH
        max_j = W - self.kW
        
        def get_stride_positions(max_idx):
            positions =[]
            curr_idx = 0
            step_count = 0
            strides = [1, 2] # The alternating strides
            
            while curr_idx <= max_idx:
                positions.append(curr_idx)
                # alternate between adding 1 and 2
                curr_idx += strides[step_count % 2]
                step_count += 1
                
            return positions

        # get the valid row and column starting positions
        valid_i = get_stride_positions(max_i)
        valid_j = get_stride_positions(max_j)
        
        # initialize the output matrix with the correct dimensions
        output = np.zeros((len(valid_i), len(valid_j)))
        
        # perform the convolution
        for out_row, i in enumerate(valid_i):
            for out_col, j in enumerate(valid_j):
                
                # extract patch
                patch = input[i : i + self.kH, j : j + self.kW]
                
                # element wise multiply with kernel and 3 and then sum result
                output[out_row, out_col] = np.sum(patch * self.kernel)

        return output
    





if __name__ == "__main__":
    input = np.array([
        [1, 2, 3, 0, 1],
        [0, 1, 2, 3, 1],
        [1, 2, 1, 0, 0],
        [0, 1, 3, 2, 1],
        [1, 0, 2, 1, 0]
    ])

    kernel = np.array([
        [1, 0],
        [0, -1]
    ])

    conv = CustomConv2D(kernel)
    output = conv.forward(input)

    print("Output:")
    print(output)

    # ExpectedOutput:
    #     [[ 0.  0. -1.]
    #     [-2.  0.  3.]
    #     [ 0. -1.  2.]]