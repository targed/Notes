import numpy as np
# do not import any other libraries.

class MultiHeadAttention:
    def __init__(self, d_model, num_heads):
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"

        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads

        # use random initialization
        self.W_q = np.random.randn(d_model, d_model)
        self.W_k = np.random.randn(d_model, d_model)
        self.W_v = np.random.randn(d_model, d_model)

    def split_heads(self, x):
        """
        Input:
            x: (batch_size, seq_len, d_model)
        Output:
            (batch_size, num_heads, seq_len, d_k)
        """
        B, N, D = x.shape

        # reshape to (B, N, num_heads, d_k)
        x_reshaped = x.reshape(B, N, self.num_heads, self.d_k)
        # transpose to (B, num_heads, N, d_k)
        x_transposed = x_reshaped.transpose(0, 2, 1, 3)
        return x_transposed

    def combine_heads(self, x):
        """
        Input:
            x: (batch_size, num_heads, seq_len, d_k)
        Output:
            (batch_size, seq_len, d_model)
        """
        B, H, N, d_k = x.shape

        # transpose to (B, N, H, d_k)
        x_transposed = x.transpose(0, 2, 1, 3)
        # reshape to (B, N, d_model)
        x_combined = x_transposed.reshape(B, N, self.d_model)
        return x_combined

    def softmax(self, x):
        """
        Standard softmax (along last dimension)
        """
        # subtract max for numerical stability before exp
        exp_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
        # divide by sum along last axis
        return exp_x / np.sum(exp_x, axis=-1, keepdims=True)

    def scaled_dot_product_attention(self, Q, K, V, scale=True):
        """
        Q, K, V: (B, num_heads, seq_len, d_k)
        """
        # compute attention scores
        # dot Q with K^T. 
        # K shape is (B, H, N, d_k) so transpose the last two dimensions: (B, H, d_k, N)
        scores = np.matmul(Q, K.transpose(0, 1, 3, 2))

        # scale. Comment this out to do with or without scaling.
        if scale:
            scores = scores / np.sqrt(self.d_k)

        # softmax
        attn = self.softmax(scores)
        output = np.matmul(attn, V)

        return output, attn

    def forward(self, X, scale=True):
        """
        X: (batch_size, seq_len, d_model)
        """
        # linear projections
        Q = np.matmul(X, self.W_q)
        K = np.matmul(X, self.W_k)
        V = np.matmul(X, self.W_v)

        # split heads
        Q = self.split_heads(Q)
        K = self.split_heads(K)
        V = self.split_heads(V)

        # Print intermediate shapes
        print(f"Shape after split_heads: Q={Q.shape}")
        
        # attention
        out, attn = self.scaled_dot_product_attention(Q, K, V, scale=scale)
        print(f"Shape of attention output: {out.shape}")

        # combine heads
        out = self.combine_heads(out)

        return out, attn


if __name__ == "__main__":
    np.random.seed(0)
    B, N, D = 2, 4, 8
    X = np.random.randn(B, N, D)

    # testing scaling
    print("=" * 50)
    print("Experiment 1: Effect of Scaling (H=2)")
    print("=" * 50)

    # Use same weights for both seed before each construction
    np.random.seed(42)
    mha_scaled = MultiHeadAttention(d_model=D, num_heads=2)
    np.random.seed(42)
    mha_unscaled = MultiHeadAttention(d_model=D, num_heads=2)

    out_s,   attn_s  = mha_scaled.forward(X, scale=True)
    out_u,   attn_u  = mha_unscaled.forward(X, scale=False)

    # Look at head 0, batch 0
    print("\nAttn weights WITH scaling    (batch=0, head=0):\n", np.round(attn_s[0, 0], 4))
    print("\nAttn weights WITHOUT scaling (batch=0, head=0):\n", np.round(attn_u[0, 0], 4))
    print("\nEntropy WITH scaling    (higher = more spread):", round(-np.sum(attn_s[0,0] * np.log(attn_s[0,0] + 1e-9), axis=-1).mean(), 4))
    print("Entropy WITHOUT scaling (lower = more peaked):  ", round(-np.sum(attn_u[0,0] * np.log(attn_u[0,0] + 1e-9), axis=-1).mean(), 4))

    print("\nStd of attn WITH scaling:   ", round(attn_s[0,0].std(), 4))
    print("Std of attn WITHOUT scaling:", round(attn_u[0,0].std(), 4))

    # Multi-Head vs Single-Head 
    print("\n" + "=" * 50)
    print("Experiment 2: Multi-Head (H=2) vs Single-Head (H=1)")
    print("=" * 50)

    np.random.seed(42)
    mha_multi  = MultiHeadAttention(d_model=D, num_heads=2)
    np.random.seed(42)
    mha_single = MultiHeadAttention(d_model=D, num_heads=1)

    out_multi,  attn_multi  = mha_multi.forward(X, scale=True)
    out_single, attn_single = mha_single.forward(X, scale=True)

    print("\nMulti-head  output (batch=0, token=0):", np.round(out_multi[0, 0], 4))
    print("Single-head output (batch=0, token=0):", np.round(out_single[0, 0], 4))
    print("\nOutput difference (L2 norm):", np.round(np.linalg.norm(out_multi - out_single), 4))