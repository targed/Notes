import numpy as np
# do not import any other libraries.

class MultiHeadAttention:
    def __init__(self, d_model, num_heads):
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"

        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads

        # TODO 1: Initialize weight matrices
        # Shapes:
        # W_q, W_k, W_v: (d_model, d_model)
        self.W_q = None
        self.W_k = None
        self.W_v = None

    def split_heads(self, x):
        """
        Input:
            x: (batch_size, seq_len, d_model)
        Output:
            (batch_size, num_heads, seq_len, d_k)
        """
        B, N, D = x.shape

        # TODO 2:
        # Step 1: reshape to (B, N, num_heads, d_k)
        # Step 2: transpose to (B, num_heads, N, d_k)
        return None

    def combine_heads(self, x):
        """
        Input:
            x: (batch_size, num_heads, seq_len, d_k)
        Output:
            (batch_size, seq_len, d_model)
        """
        B, H, N, d_k = x.shape

        # TODO 3:
        # Step 1: transpose to (B, N, H, d_k)
        # Step 2: reshape to (B, N, d_model)
        return None

    def softmax(self, x):
        """
        Standard softmax (along last dimension)
        """
        # TODO 4:
        # exp
        # divide by sum along last axis
        return None

    def scaled_dot_product_attention(self, Q, K, V):
        """
        Q, K, V: (B, num_heads, seq_len, d_k)
        """
        # TODO 5: compute attention scores
        # The line below is incorrect, please revise it.
        scores = np.matmul(Q, K)

        # TODO 6: scale
        scores = None

        # TODO 7: softmax
        attn = None

        # TODO 8: weighted sum
        output = None

        return output

    def forward(self, X):
        """
        X: (batch_size, seq_len, d_model)
        """
        # TODO 9: linear projections
        Q = None
        K = None
        V = None

        # TODO: print the following intermediate shapes:
        # after split:
        # attention matrix (head 0):

        # TODO 10: split heads
        Q = self.split_heads(Q)
        K = self.split_heads(K)
        V = self.split_heads(V)

        # TODO 11: attention
        out = self.scaled_dot_product_attention(Q, K, V)

        # TODO 12: combine heads
        out = self.combine_heads(out)

        return out


if __name__ == "__main__":
    np.random.seed(0)

    B, N, D = 2, 4, 8
    H = 2

    X = np.random.randn(B, N, D)

    mha = MultiHeadAttention(d_model=D, num_heads=H)

    # TODO: initialize weights before running
    output = mha.forward(X)

    print("Output shape:", output.shape)  # Expected: (2, 4, 8)