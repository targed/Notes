import numpy as np
# Do not import any additional libraries here. You may only use numpy and standard Python libraries.


def initialize_centroids(X, K):
    """
    Randomly initialize K centroids from the dataset.

    Parameters
    ----------
    X : numpy array of shape (n_samples, n_features)
    K : int
        Number of clusters

    Returns
    -------
    centroids : numpy array of shape (K, n_features)
    """

    # TODO: randomly select K data points as centroids
    pass


def assign_clusters(X, centroids):
    """
    Assign each data point to the nearest centroid.

    Parameters
    ----------
    X : numpy array (n_samples, n_features)
    centroids : numpy array (K, n_features)

    Returns
    -------
    labels : numpy array (n_samples,)
        Cluster index for each data point
    """

    # TODO: compute distance from each point to each centroid
    # TODO: assign cluster based on nearest centroid
    pass


def update_centroids(X, labels, K):
    """
    Update centroid positions based on cluster assignments.

    Parameters
    ----------
    X : numpy array (n_samples, n_features)
    labels : numpy array (n_samples,)
    K : int

    Returns
    -------
    centroids : numpy array (K, n_features)
    """

    # TODO: compute the mean of each cluster and update centroids
    pass


def compute_sse(X, labels, centroids):
    """
    Compute the Sum of Squared Errors (SSE).

    Parameters
    ----------
    X : numpy array
    labels : numpy array
    centroids : numpy array

    Returns
    -------
    sse : float
    """

    # TODO: sum squared distance between each point and its centroid
    pass


def kmeans(X, K, max_iter=100):
    """
    Basic K-Means clustering algorithm.

    Parameters
    ----------
    X : numpy array (n_samples, n_features)
    K : int
    max_iter : int

    Returns
    -------
    labels : numpy array
    centroids : numpy array
    sse : float
    """

    # Step 1: initialize centroids
    centroids = initialize_centroids(X, K)

    for _ in range(max_iter):

        # Step 2: assign clusters
        labels = assign_clusters(X, centroids)

        # Step 3: update centroids
        new_centroids = update_centroids(X, labels, K)

        # Step 4: check convergence
        # TODO: stop if centroids do not change significantly
        pass

    # Step 5: compute final SSE
    sse = compute_sse(X, labels, centroids)

    return labels, centroids, sse


def kmeans_with_restarts(X, K, n_runs=10):
    """
    Run K-Means multiple times to reduce the effect of random initialization.

    Parameters
    ----------
    X : numpy array
    K : int
    n_runs : int

    Returns
    -------
    best_labels
    best_centroids
    best_sse
    """

    # TODO:
    # Run kmeans() multiple times
    # Track the result with the lowest SSE
    pass