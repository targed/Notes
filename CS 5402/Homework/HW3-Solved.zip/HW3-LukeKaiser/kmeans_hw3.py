import numpy as np
# Do not import any additional libraries here. You may only use numpy and standard Python libraries.


def initialize_centroids(X, K):
    """
    Randomly initialize K centroids from the dataset.

    Parameters
    ----------
    X : numpy array of shape (n_samples, n_features)
    K : int
        Number of clusters

    Returns
    -------
    centroids : numpy array of shape (K, n_features)
    """

    # select K random unique indices from the number of samples
    n_samples = X.shape[0]
    random_indices = np.random.choice(n_samples, K, replace=False)
    
    # use these indices to pull the actual data points as initial centroids
    centroids = X[random_indices]
    return centroids


def assign_clusters(X, centroids):
    """
    Assign each data point to the nearest centroid.

    Parameters
    ----------
    X : numpy array (n_samples, n_features)
    centroids : numpy array (K, n_features)

    Returns
    -------
    labels : numpy array (n_samples,)
        Cluster index for each data point
    """
    
    n_samples = X.shape[0]
    K = centroids.shape[0]
    n_features = X.shape[1]

    diff = np.zeros((n_samples, K, n_features))

    for i in range(n_samples):
        for j in range(K):
            for f in range(n_features):
                diff[i, j, f] = X[i, f] - centroids[j, f]
    distances = np.sum(diff ** 2, axis=2)
    
    # find the index of the minimum distance for each sample
    labels = np.argmin(distances, axis=1)
    return labels


def update_centroids(X, labels, K):
    """
    Update centroid positions based on cluster assignments.

    Parameters
    ----------
    X : numpy array (n_samples, n_features)
    labels : numpy array (n_samples,)
    K : int

    Returns
    -------
    centroids : numpy array (K, n_features)
    """

    n_features = X.shape[1]
    new_centroids = np.zeros((K, n_features))
    
    for k in range(K):
        # extract all points assigned to cluster k
        cluster_points = X[labels == k]
        
        if len(cluster_points) > 0:
            # set the new centroid to the mean of these points
            new_centroids[k] = np.mean(cluster_points, axis=0)
        else:
            # handle empty cluster by picking a new random point to avoid NaN
            new_centroids[k] = X[np.random.choice(X.shape[0])]
            
    return new_centroids


def compute_sse(X, labels, centroids):
    """
    Compute the Sum of Squared Errors (SSE).

    Parameters
    ----------
    X : numpy array
    labels : numpy array
    centroids : numpy array

    Returns
    -------
    sse : float
    """

    # map the centroid for each point using the labels
    assigned_centroids = centroids[labels]
    
    # calculate squared differences and sum them up
    sse = np.sum((X - assigned_centroids) ** 2)
    return float(sse)


def kmeans(X, K, max_iter=100):
    """
    Basic K-Means clustering algorithm.

    Parameters
    ----------
    X : numpy array (n_samples, n_features)
    K : int
    max_iter : int

    Returns
    -------
    labels : numpy array
    centroids : numpy array
    sse : float
    """

    # Step 1: initialize centroids
    centroids = initialize_centroids(X, K)

    for _ in range(max_iter):

        # Step 2: assign clusters
        labels = assign_clusters(X, centroids)

        # Step 3: update centroids
        new_centroids = update_centroids(X, labels, K)

        # Step 4: check convergence
        # converged if centroids do not change
        if np.all(centroids == new_centroids):
            break
        
        centroids = new_centroids

    # Step 5: compute final SSE
    sse = compute_sse(X, labels, centroids)

    return labels, centroids, sse


def kmeans_with_restarts(X, K, n_runs=10):
    """
    Run K-Means multiple times to reduce the effect of random initialization.

    Parameters
    ----------
    X : numpy array
    K : int
    n_runs : int

    Returns
    -------
    best_labels
    best_centroids
    best_sse
    """

    # Start with an infinitely high SSE
    best_sse = float('inf')
    best_labels = None
    best_centroids = None

    for _ in range(n_runs):
        # Run the standard K-Means algorithm once
        labels, centroids, sse = kmeans(X, K)
        
        # if lower SSE is found, update the best results
        if sse < best_sse:
            best_sse = sse
            best_labels = labels
            best_centroids = centroids

    return best_labels, best_centroids, best_sse

def compute_elbow(X, max_k=10):
    """
    Returns a list of inertia values for K = 1 to max_k, and optimal K value.
    """
    sse_values =[]
    
    # run K Means for K = 1 to max k and record SSE
    for k in range(1, max_k + 1):
        # using n runs = 5 is a good balance between finding a good minimum and code speed
        _, _, sse = kmeans_with_restarts(X, k, n_runs=5)
        sse_values.append(sse)
        
    # find the point furthest from the line that connects the first and last points of the curve
    
    x1, y1 = 1, sse_values[0]
    x2, y2 = max_k, sse_values[-1]
    
    max_distance = -1
    optimal_k = 1
    
    for k in range(1, max_k + 1):
        x0 = k
        y0 = sse_values[k - 1] # Index is k-1 because k starts at 1
        
        # calculate the perpendicular distance from point (x0, y0) to the line
        distance = abs((x2 - x1) * (y1 - y0) - (x1 - x0) * (y2 - y1))
        
        # track the point with the maximum distance
        if distance > max_distance:
            max_distance = distance
            optimal_k = k

    return sse_values, optimal_k