import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from kmeans_hw3 import compute_elbow

# generate some dummy data with 4 distinct clusters
X, _ = make_blobs(n_samples=300, centers=4, random_state=42)

# run compute_elbow to get SSE values and optimal K
max_k = 10
sse_values, optimal_k = compute_elbow(X, max_k)

print(f"Algorithmically found Optimal K: {optimal_k}")

# plot the results
plt.figure(figsize=(8, 5))
plt.plot(range(1, max_k + 1), sse_values, marker='o', linestyle='-', color='b')
plt.axvline(x=optimal_k, color='red', linestyle='--', label=f'Optimal K = {optimal_k}')

plt.title('Elbow Method for Optimal K')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Sum of Squared Errors (SSE)')
plt.xticks(range(1, max_k + 1))
plt.legend()
plt.grid(True)
plt.show()