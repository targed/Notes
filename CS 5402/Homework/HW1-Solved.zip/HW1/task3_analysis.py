import numpy as np
import student_hw1 as hw
import matplotlib.pyplot as plt

# seed for reproducibility
np.random.seed(42)

# construct balanced dataset
n_pos_bal = 50
n_neg_bal = 50

# synthetic scores
scores_neg_bal = np.random.normal(loc=0.3, scale=0.15, size=n_neg_bal)
scores_pos_bal = np.random.normal(loc=0.7, scale=0.15, size=n_pos_bal)

y_true_bal = np.concatenate([np.zeros(n_neg_bal), np.ones(n_pos_bal)])

y_score_bal = np.concatenate([scores_neg_bal, scores_pos_bal])
y_score_bal = np.clip(y_score_bal, 0, 1)

print("Plotting Balanced Dataset ROC...")
hw.plot_roc_curve(y_true_bal, y_score_bal)


# construct imbalanced dataset
n_pos_im = 5
n_neg_im = 95

# similar distributions 
scores_neg_im = np.random.normal(loc=0.3, scale=0.15, size=n_neg_im)
scores_pos_im = np.random.normal(loc=0.7, scale=0.15, size=n_pos_im)

y_true_im = np.concatenate([np.zeros(n_neg_im), np.ones(n_pos_im)])

y_score_im = np.concatenate([scores_neg_im, scores_pos_im])
y_score_im = np.clip(y_score_im, 0, 1)

print("Plotting Imbalanced Dataset ROC...")
hw.plot_roc_curve(y_true_im, y_score_im)