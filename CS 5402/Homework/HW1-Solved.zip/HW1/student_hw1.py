import numpy as np
import matplotlib.pyplot as plt
# DO NOT import any other libraries.


def confusion_matrix_metrics(conf_mat):
    """
    Compute evaluation metrics from a confusion matrix.

    Parameters
    ----------
    conf_mat : np.ndarray of shape (K, K)
        Confusion matrix where conf_mat[i, j] is the number of
        samples with true label i predicted as label j.

    Returns
    -------
    metrics : np.ndarray of shape (K, 4)
        Each row corresponds to one class.
        Columns are:
        [accuracy, recall, precision, f1_score]
    """

    # variables to store results
    K = conf_mat.shape[0]
    metrics = np.zeros((K, 4), dtype=float)
    total_samples = np.sum(conf_mat)
    actual_totals = np.sum(conf_mat, axis=1)
    predicted_totals = np.sum(conf_mat, axis=0)
    
    for i in range(K):
        # 1. Extract Binary Confusion Matrix Components (One-vs-Rest)
        
        # TP: Correctly predicted as class i
        tp = conf_mat[i, i]
        
        # FP: Predicted as i, but actually not i (Column sum - TP)
        fp = predicted_totals[i] - tp
        
        # FN: Actually i, but predicted as not i (Row sum - TP)
        fn = actual_totals[i] - tp
        
        # TN: Actually not i, predicted as not i (Total - (TP + FP + FN))
        tn = total_samples - (tp + fp + fn)
        
        # 2. Compute Metrics with Zero Division Handling
        
        # Accuracy: (TP + TN) / Total
        if total_samples == 0:
            accuracy = 0.0
        else:
            accuracy = (tp + tn) / total_samples
            
        # Recall: TP / (TP + FN) -> TP / Actual Total
        denominator_recall = tp + fn
        if denominator_recall == 0:
            recall = 0.0
        else:
            recall = tp / denominator_recall
            
        # Precision: TP / (TP + FP) -> TP / Predicted Total
        denominator_precision = tp + fp
        if denominator_precision == 0:
            precision = 0.0
        else:
            precision = tp / denominator_precision
            
        # F1-score: Harmonic mean of Precision and Recall
        denominator_f1 = precision + recall
        if denominator_f1 == 0:
            f1_score = 0.0
        else:
            f1_score = 2 * (precision * recall) / denominator_f1
            
        # Store results in the metrics array
        metrics[i, 0] = accuracy
        metrics[i, 1] = recall
        metrics[i, 2] = precision
        metrics[i, 3] = f1_score

    return metrics




def plot_roc_curve(y_true, y_score, num_thresholds=100):
    """
    Plot ROC curve from ground-truth labels and predicted probabilities.

    Parameters
    ----------
    y_true : array-like of shape (n_samples,)
        Ground truth binary labels (0 or 1)

    y_score : array-like of shape (n_samples,)
        Predicted probabilities for the input

    num_thresholds : int
        Number of thresholds to evaluate (default=100)

    Returns
    -------
    fpr : np.ndarray
        False Positive Rates

    tpr : np.ndarray
        True Positive Rates
    """


    tpr_list = []
    fpr_list = []

    # Pre-calculate totals for Positive (P) and Negative (N) classes
    P = np.sum(y_true == 1)
    N = np.sum(y_true == 0)

    thresholds = np.linspace(1, 0, num_thresholds)

    for t in thresholds:
        # positive if score >= threshold
        y_pred = (y_score >= t).astype(int)

        # TP: Predicted 1 and Actual 1
        tp = np.sum((y_pred == 1) & (y_true == 1))
        
        # FP: Predicted 1 and Actual 0
        fp = np.sum((y_pred == 1) & (y_true == 0))

        # Calculate Rates (Handle division by zero if dataset is degenerate)
        tpr = tp / P if P > 0 else 0.0
        fpr = fp / N if N > 0 else 0.0

        tpr_list.append(tpr)
        fpr_list.append(fpr)

    fpr_arr = np.array(fpr_list)
    tpr_arr = np.array(tpr_list)

    # thresholds 0.5 and 0.8
    special_thresholds = [0.5, 0.8]
    special_points = []

    for t in special_thresholds:
        y_pred = (y_score >= t).astype(int)
        tp = np.sum((y_pred == 1) & (y_true == 1))
        fp = np.sum((y_pred == 1) & (y_true == 0))
        
        Spec_tpr = tp / P if P > 0 else 0.0
        Spec_fpr = fp / N if N > 0 else 0.0
        special_points.append((Spec_fpr, Spec_tpr, str(t)))

    # Plot ROC curve
    # plt.figure()
    # plt.plot(fpr_list, tpr_list, label="ROC Curve")
    # plt.plot([0, 1], [0, 1], linestyle="--", label="Random Guess")
    # plt.xlabel("False Positive Rate")
    # plt.ylabel("True Positive Rate")
    # plt.title("ROC Curve")
    # plt.legend()
    # plt.show()    
    
    # Can we change this? Not sure if this is allowed but it looks nicer with bigger font and grid and points and stuff
    # If not, just uncomment the above and comment out this block
    plt.figure(figsize=(8, 6))
    plt.plot(fpr_arr, tpr_arr, label="ROC Curve", color='blue')
    plt.plot([0, 1], [0, 1], linestyle="--", label="Random Guess", color='gray')
    # Plot the red points
    for pt in special_points:
        plt.plot(pt[0], pt[1], 'ro')
        plt.annotate(f"t={pt[2]}", (pt[0], pt[1]), xytext=(10, -10), 
                     textcoords='offset points', color='red')
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend(loc="lower right")
    plt.grid(alpha=0.3)
    plt.show()
    

    return np.array(fpr_list), np.array(tpr_list)